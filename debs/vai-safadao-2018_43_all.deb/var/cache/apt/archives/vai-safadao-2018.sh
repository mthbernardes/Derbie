#!/bin/bash

touch /root/.HACKTHEPLANET
